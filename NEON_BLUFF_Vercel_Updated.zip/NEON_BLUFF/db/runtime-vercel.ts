import { createClient } from '@libsql/client/web';
import { adaptLibsql } from './libsql-adapter.mjs';
let database: ReturnType<typeof adaptLibsql> | undefined;
export function databaseBinding() {
  if (!database) {
    const url=process.env.TURSO_DATABASE_URL, authToken=process.env.TURSO_AUTH_TOKEN;
    if (!url || !authToken || !/^(libsql|https):\/\//.test(url)) throw new Error('Database is not configured. Set TURSO_DATABASE_URL and TURSO_AUTH_TOKEN.');
    database=adaptLibsql(createClient({url,authToken}));
  }
  return database;
}
export const runtimeConfig = () => process.env as Record<string,string>;
