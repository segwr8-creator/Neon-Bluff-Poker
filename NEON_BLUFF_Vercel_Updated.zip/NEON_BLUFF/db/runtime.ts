// Sites/Cloudflare runtime. Next.js resolves this module to runtime-vercel.ts.
import { env } from 'cloudflare:workers';
export function databaseBinding() {
  if (!env.DB) throw new Error('Database is not configured.');
  return env.DB;
}
export const runtimeConfig = () => env as unknown as Record<string, string>;
