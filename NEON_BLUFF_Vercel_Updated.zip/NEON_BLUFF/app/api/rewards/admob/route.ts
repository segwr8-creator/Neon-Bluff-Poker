import { roomDb } from '../../../../db';
import { adsReady, response, verifyAd, grant, AD_REWARD } from '../../../../lib/monetization';
export const dynamic='force-dynamic';
export async function GET(req:Request){
 if(!adsReady())return response({error:'Rewarded ads are not enabled.'},503);
 try{
  const p=await verifyAd(req),transaction=p.get('transaction_id')||'';
  if(!/^[a-zA-Z0-9_-]{1,200}$/.test(transaction))throw new Error('Invalid transaction.');
  const intent:any=await roomDb().prepare('SELECT * FROM refill_intents WHERE id=? AND kind=?').bind(p.get('custom_data'), 'ad').first();
  const time=Number(p.get('timestamp'));
  if(!intent||p.get('user_id')!==intent.profile_id||!Number.isFinite(time)||time<intent.created-60000||time>intent.expires)throw new Error('Reward session does not match.');
  // Signed event time is bounded, but delayed authentic callbacks can still settle.
  await grant('admob:'+transaction,intent,'admob','ad_refill_50',AD_REWARD);
  return response({received:true});
 }catch{return response({error:'Reward could not be verified.'},400)}
}
